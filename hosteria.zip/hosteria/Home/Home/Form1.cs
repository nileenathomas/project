﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home
{
    public partial class Form1 : Form
    {
        UserControl wp, lp;
        public Form1()
        {
            wp = wardenprofile1;
            lp = leaveProcessing1;
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            wp.Show();
            this.Controls.Add(wp);
            lp.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lp.Show();
                this.Controls.Add(lp);

                wp.Hide();
        }

    }
}
